<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Números em ordem</h1>
    <form action="app.php" method="post">
        <label>Escreva o número de início: </label>
            <input type="text" name="inicial">
        <label>Número final: </label> 
            <input type="text" name="final">

        <button type="submit">Imprimir</button>
    </form>
</body>
</html>