<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Você já votou!</title>
</head>
<body>
    <h1>Você ja votou!</h1>
    <h2>Volte para a página inicial</h2>
    <button type="button" onclick="location.href='index.php'">Voltar</button>
</body>
</html>