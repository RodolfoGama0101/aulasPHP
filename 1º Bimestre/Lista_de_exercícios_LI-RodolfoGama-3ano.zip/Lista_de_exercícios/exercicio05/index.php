<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votação</title>
</head>

<body>
    <h1>Votação</h1>
    <h2>Bebida favorita:</h2>

    <form action="app.php" method="get">
        <input type="radio" name="radio-input" value="coca-cola">Cola-Cola</input> <br>
        <input type="radio" name="radio-input" value="sprite">Sprite</input> <br>
        <input type="radio" name="radio-input" value="fanta">Fanta</input> <br>
        <input type="radio" name="radio-input" value="pepsi">Pepsi</input> <br>
        <input type="radio" name="radio-input" value="cafe">Café</input> <br>

        <button type="submit">Enviar</button>

        <?php 
            
        ?>
    </form>
</body>

</html>