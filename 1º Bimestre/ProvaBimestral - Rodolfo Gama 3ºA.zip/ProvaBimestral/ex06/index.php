<?php 
    $x = 10;
    $y = 19;
    $z = 28;

    echo ++$x; echo "<br>";
    echo $y++; echo "<br>";
    echo --$z; echo "<br>";
?>